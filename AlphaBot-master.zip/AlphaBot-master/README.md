# Checking <em>Your</em> Version.

## first head to the command prompt and type a command
This will let us determine what version it is and type in  `pip show discord` or `pip3 show discord.py` to see which version applies to you


### If it Shows v0.16.x
Goto `async branch`. and consider getting 1.0.0a , <em>note that async branch is no longer worked on by me :D</em><h6>down below</h6>

### If It Shows 1.0.0a 
Goto `rewrite branch.` 
If you do not have rewrite then copy paste ```pip install -U git+https://github.com/Rapptz/discord.py@rewrite#egg=discord.py[voice]``` if you want voice and the version if you dont want voice then simply remove [voice] at the end.


